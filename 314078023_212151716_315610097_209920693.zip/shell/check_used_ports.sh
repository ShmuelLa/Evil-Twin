sudo lsof -i -P -n | grep LIST
echo "============================================================="
sudo ss -lp "sport = :domain"